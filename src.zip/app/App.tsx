import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './components/ui/card';
import { Button } from './components/ui/button';
import { Input } from './components/ui/input';
import { Slider } from './components/ui/slider';
import { Badge } from './components/ui/badge';
import { Alert, AlertDescription } from './components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { LineChart, Line, BarChart, Bar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Brain, Heart, Moon, Smartphone, Activity, TrendingUp, AlertTriangle, Phone, MessageCircle, Users, Home, Calendar, BarChart3, BookOpen, LogOut, Sparkles, Star, Eye, EyeOff, Trash2, ExternalLink } from 'lucide-react';

interface User {
  id: string;
  name: string;
  email: string;
}

interface Entry {
  date: string;
  mood: number;
  sleep: number;
  screenTime: number;
  exercise: number;
}

interface UserData {
  entries: Entry[];
}

const moodEmojis = ['😢', '😟', '😐', '🙂', '😊'];
const moodLabels = ['Muito Triste', 'Triste', 'Neutro', 'Feliz', 'Muito Feliz'];

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [activeTab, setActiveTab] = useState('dashboard');
  const [showPassword, setShowPassword] = useState(false);

  // Estado do registo diário - VALORES EM TEMPO REAL
  const [mood, setMood] = useState(3);
  const [sleep, setSleep] = useState(7);
  const [screenTime, setScreenTime] = useState(4);
  const [exercise, setExercise] = useState(30);

  useEffect(() => {
    const savedUser = localStorage.getItem('currentUser');
    if (savedUser) {
      setCurrentUser(JSON.parse(savedUser));
    }
  }, []);

  const getUserData = (): UserData => {
    if (!currentUser) return { entries: [] };
    const data = localStorage.getItem(`userData_${currentUser.id}`);
    return data ? JSON.parse(data) : { entries: [] };
  };

  const saveUserData = (data: UserData) => {
    if (currentUser) {
      localStorage.setItem(`userData_${currentUser.id}`, JSON.stringify(data));
    }
  };

  const handleAuth = () => {
    if (isLogin) {
      const users = JSON.parse(localStorage.getItem('users') || '[]');
      const user = users.find((u: User) => u.email === email);
      if (user) {
        setCurrentUser(user);
        localStorage.setItem('currentUser', JSON.stringify(user));
      } else {
        alert('Utilizador não encontrado!');
      }
    } else {
      const users = JSON.parse(localStorage.getItem('users') || '[]');
      const newUser: User = {
        id: Date.now().toString(),
        name,
        email
      };
      users.push(newUser);
      localStorage.setItem('users', JSON.stringify(users));
      setCurrentUser(newUser);
      localStorage.setItem('currentUser', JSON.stringify(newUser));
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('currentUser');
    setEmail('');
    setPassword('');
    setName('');
    setShowPassword(false);
  };

  const handleDeleteEntry = (date: string) => {
    if (window.confirm('Tens a certeza que queres eliminar este registo?')) {
      const userData = getUserData();
      userData.entries = userData.entries.filter(e => e.date !== date);
      saveUserData(userData);
      alert('Registo eliminado com sucesso! 🗑️');
    }
  };

  const handleSubmitEntry = () => {
    const userData = getUserData();
    const today = new Date().toISOString().split('T')[0];

    const newEntry: Entry = {
      date: today,
      mood,
      sleep,
      screenTime,
      exercise
    };

    const existingIndex = userData.entries.findIndex(e => e.date === today);
    if (existingIndex >= 0) {
      userData.entries[existingIndex] = newEntry;
    } else {
      userData.entries.push(newEntry);
    }

    userData.entries.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    saveUserData(userData);

    alert('Registo guardado com sucesso! ✅');
    setActiveTab('dashboard');
  };

  const getStats = () => {
    const userData = getUserData();
    if (userData.entries.length === 0) {
      return { avgMood: 0, avgSleep: 0, avgScreen: 0, avgExercise: 0 };
    }

    const total = userData.entries.reduce((acc, entry) => ({
      mood: acc.mood + entry.mood,
      sleep: acc.sleep + entry.sleep,
      screenTime: acc.screenTime + entry.screenTime,
      exercise: acc.exercise + entry.exercise
    }), { mood: 0, sleep: 0, screenTime: 0, exercise: 0 });

    const count = userData.entries.length;
    return {
      avgMood: (total.mood / count).toFixed(1),
      avgSleep: (total.sleep / count).toFixed(1),
      avgScreen: (total.screenTime / count).toFixed(1),
      avgExercise: (total.exercise / count).toFixed(0)
    };
  };

  const detectAlerts = () => {
    const userData = getUserData();
    const recent = userData.entries.slice(0, 7);
    const alerts = [];

    if (recent.length >= 3) {
      const avgMood = recent.reduce((sum, e) => sum + e.mood, 0) / recent.length;
      const avgSleep = recent.reduce((sum, e) => sum + e.sleep, 0) / recent.length;
      const avgScreen = recent.reduce((sum, e) => sum + e.screenTime, 0) / recent.length;

      if (avgMood < 2) alerts.push({ type: 'Humor Baixo', message: 'O teu humor tem estado consistentemente baixo. Considera falar com alguém.' });
      if (avgSleep < 6) alerts.push({ type: 'Sono Insuficiente', message: 'Estás a dormir menos de 6 horas. O descanso é essencial!' });
      if (avgScreen > 6) alerts.push({ type: 'Tempo de Ecrã Alto', message: 'Muito tempo no ecrã pode afetar o teu bem-estar.' });
    }

    return alerts;
  };

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-500 via-pink-500 to-red-500 flex items-center justify-center p-4 relative overflow-hidden">
        {/* Elementos flutuantes de fundo */}
        <motion.div
          className="absolute top-20 left-10 text-white/20 text-6xl"
          animate={{ y: [0, -20, 0], rotate: [0, 10, 0] }}
          transition={{ duration: 4, repeat: Infinity }}
        >
          ⭐
        </motion.div>
        <motion.div
          className="absolute bottom-20 right-20 text-white/20 text-8xl"
          animate={{ y: [0, 20, 0], rotate: [0, -10, 0] }}
          transition={{ duration: 5, repeat: Infinity }}
        >
          💜
        </motion.div>
        <motion.div
          className="absolute top-1/2 right-10 text-white/20 text-5xl"
          animate={{ y: [0, -30, 0], rotate: [0, 15, 0] }}
          transition={{ duration: 3.5, repeat: Infinity }}
        >
          ✨
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
        >
          <Card className="w-full max-w-md backdrop-blur-xl bg-white/90 shadow-2xl border-0">
            <CardHeader className="space-y-4 text-center">
              <motion.div
                className="flex justify-center"
                animate={{ scale: [1, 1.1, 1], rotate: [0, 5, -5, 0] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <div className="bg-gradient-to-br from-purple-500 to-pink-500 p-4 rounded-full shadow-lg">
                  <Brain className="w-12 h-12 text-white" />
                </div>
              </motion.div>
              <div>
                <CardTitle className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                  MindData
                </CardTitle>
                <CardDescription className="text-lg mt-2">
                  O teu espaço seguro de bem-estar mental
                </CardDescription>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <Tabs value={isLogin ? 'login' : 'signup'} onValueChange={(v) => setIsLogin(v === 'login')} className="w-full">
                <TabsList className="grid w-full grid-cols-2 bg-gradient-to-r from-purple-100 to-pink-100">
                  <TabsTrigger value="login" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-500 data-[state=active]:to-pink-500 data-[state=active]:text-white">
                    Entrar
                  </TabsTrigger>
                  <TabsTrigger value="signup" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-500 data-[state=active]:to-pink-500 data-[state=active]:text-white">
                    Registar
                  </TabsTrigger>
                </TabsList>
                <TabsContent value="login" className="space-y-4 mt-4">
                  <Input
                    type="email"
                    placeholder="Email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="border-purple-200 focus:border-purple-500"
                  />
                  <div className="relative">
                    <Input
                      type={showPassword ? "text" : "password"}
                      placeholder="Password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="border-purple-200 focus:border-purple-500 pr-10"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-purple-600 transition-colors"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  <Button
                    onClick={handleAuth}
                    className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white shadow-lg"
                  >
                    Entrar
                  </Button>
                </TabsContent>
                <TabsContent value="signup" className="space-y-4 mt-4">
                  <Input
                    type="text"
                    placeholder="Nome"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="border-pink-200 focus:border-pink-500"
                  />
                  <Input
                    type="email"
                    placeholder="Email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="border-pink-200 focus:border-pink-500"
                  />
                  <div className="relative">
                    <Input
                      type={showPassword ? "text" : "password"}
                      placeholder="Password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="border-pink-200 focus:border-pink-500 pr-10"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-pink-600 transition-colors"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  <Button
                    onClick={handleAuth}
                    className="w-full bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600 text-white shadow-lg"
                  >
                    Criar Conta
                  </Button>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    );
  }

  const stats = getStats();
  const alerts = detectAlerts();
  const userData = getUserData();
  const chartData = userData.entries.slice(0, 7).reverse().map(e => ({
    data: e.date.split('-').slice(1).join('/'),
    Humor: e.mood,
    Sono: e.sleep,
    'Tempo Ecrã': e.screenTime,
    Exercício: e.exercise / 10
  }));

  const radarData = [
    { category: 'Humor', value: parseFloat(stats.avgMood) * 20 },
    { category: 'Sono', value: parseFloat(stats.avgSleep) * 10 },
    { category: 'Exercício', value: parseFloat(stats.avgExercise) / 3 },
    { category: 'Ecrã (inv)', value: (12 - parseFloat(stats.avgScreen)) * 8 }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-purple-50 to-pink-50 relative overflow-hidden">
      {/* Elementos decorativos de fundo */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div
          className="absolute -top-20 -right-20 w-96 h-96 bg-purple-200 rounded-full opacity-20 blur-3xl"
          animate={{ scale: [1, 1.2, 1], x: [0, 50, 0] }}
          transition={{ duration: 8, repeat: Infinity }}
        />
        <motion.div
          className="absolute -bottom-20 -left-20 w-96 h-96 bg-pink-200 rounded-full opacity-20 blur-3xl"
          animate={{ scale: [1, 1.3, 1], x: [0, -50, 0] }}
          transition={{ duration: 10, repeat: Infinity }}
        />
      </div>

      {/* Header */}
      <header className="backdrop-blur-xl bg-white/70 border-b border-purple-100 sticky top-0 z-50 shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <motion.div
              className="flex items-center gap-3"
              whileHover={{ scale: 1.05 }}
            >
              <div className="bg-gradient-to-br from-purple-500 to-pink-500 p-2 rounded-xl shadow-lg">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                  MindData
                </h1>
                <p className="text-xs text-gray-500">Olá, {currentUser.name}! ✨</p>
              </div>
            </motion.div>
            <Button
              variant="ghost"
              onClick={handleLogout}
              className="hover:bg-red-50 hover:text-red-600 transition-colors"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Sair
            </Button>
          </div>
        </div>
      </header>

      {/* Navegação */}
      <div className="container mx-auto px-4 py-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-white/70 backdrop-blur-xl border border-purple-100 p-1 shadow-sm">
            <TabsTrigger
              value="dashboard"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-500 data-[state=active]:to-pink-500 data-[state=active]:text-white transition-all"
            >
              <Home className="w-4 h-4 mr-2" />
              Dashboard
            </TabsTrigger>
            <TabsTrigger
              value="entry"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-pink-500 data-[state=active]:to-purple-500 data-[state=active]:text-white transition-all"
            >
              <Calendar className="w-4 h-4 mr-2" />
              Registo
            </TabsTrigger>
            <TabsTrigger
              value="analysis"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-indigo-500 data-[state=active]:to-cyan-500 data-[state=active]:text-white transition-all"
            >
              <BarChart3 className="w-4 h-4 mr-2" />
              Análise
            </TabsTrigger>
            <TabsTrigger
              value="resources"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-cyan-500 data-[state=active]:to-indigo-500 data-[state=active]:text-white transition-all"
            >
              <BookOpen className="w-4 h-4 mr-2" />
              Recursos
            </TabsTrigger>
          </TabsList>

          {/* Dashboard */}
          <TabsContent value="dashboard" className="space-y-6 mt-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h2 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent mb-6">
                O Teu Bem-Estar em Números
              </h2>

              {/* Alertas */}
              {alerts.length > 0 && (
                <motion.div
                  className="space-y-3 mb-6"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                >
                  {alerts.map((alert, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.1 }}
                    >
                      <Alert className="border-orange-200 bg-gradient-to-r from-orange-50 to-red-50 shadow-md">
                        <AlertTriangle className="h-5 w-5 text-orange-600" />
                        <AlertDescription className="ml-2">
                          <span className="font-semibold text-orange-900">{alert.type}:</span>{' '}
                          <span className="text-orange-800">{alert.message}</span>
                        </AlertDescription>
                      </Alert>
                    </motion.div>
                  ))}
                </motion.div>
              )}

              {/* Estatísticas */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 }}
                  whileHover={{ scale: 1.05, y: -5 }}
                >
                  <Card className="bg-gradient-to-br from-purple-500 to-pink-500 text-white border-0 shadow-xl">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <Heart className="w-12 h-12 opacity-80" />
                        <span className="text-5xl">{moodEmojis[Math.round(parseFloat(stats.avgMood) || 3) - 1]}</span>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-3xl font-bold">{stats.avgMood}/5</p>
                      <p className="text-sm opacity-90 mt-1">Humor Médio</p>
                    </CardContent>
                  </Card>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                  whileHover={{ scale: 1.05, y: -5 }}
                >
                  <Card className="bg-gradient-to-br from-indigo-500 to-blue-500 text-white border-0 shadow-xl">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <Moon className="w-12 h-12 opacity-80" />
                        <span className="text-5xl">😴</span>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-3xl font-bold">{stats.avgSleep}h</p>
                      <p className="text-sm opacity-90 mt-1">Sono Médio</p>
                    </CardContent>
                  </Card>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                  whileHover={{ scale: 1.05, y: -5 }}
                >
                  <Card className="bg-gradient-to-br from-cyan-500 to-teal-500 text-white border-0 shadow-xl">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <Smartphone className="w-12 h-12 opacity-80" />
                        <span className="text-5xl">📱</span>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-3xl font-bold">{stats.avgScreen}h</p>
                      <p className="text-sm opacity-90 mt-1">Tempo de Ecrã</p>
                    </CardContent>
                  </Card>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                  whileHover={{ scale: 1.05, y: -5 }}
                >
                  <Card className="bg-gradient-to-br from-green-500 to-emerald-500 text-white border-0 shadow-xl">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <Activity className="w-12 h-12 opacity-80" />
                        <span className="text-5xl">🏃</span>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-3xl font-bold">{stats.avgExercise}min</p>
                      <p className="text-sm opacity-90 mt-1">Exercício Diário</p>
                    </CardContent>
                  </Card>
                </motion.div>
              </div>

              {/* Gráfico de Tendências */}
              {chartData.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 }}
                >
                  <Card className="mt-6 bg-white/70 backdrop-blur-xl border-purple-100 shadow-lg">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2 text-2xl bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                        <TrendingUp className="w-6 h-6 text-purple-500" />
                        Tendências dos Últimos 7 Dias
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ResponsiveContainer width="100%" height={300}>
                        <LineChart data={chartData}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#e9d5ff" />
                          <XAxis dataKey="data" stroke="#9333ea" />
                          <YAxis stroke="#9333ea" />
                          <Tooltip
                            contentStyle={{
                              backgroundColor: 'rgba(255, 255, 255, 0.95)',
                              borderRadius: '12px',
                              border: '1px solid #e9d5ff',
                              boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)'
                            }}
                          />
                          <Legend />
                          <Line type="monotone" dataKey="Humor" stroke="#ec4899" strokeWidth={3} dot={{ fill: '#ec4899', r: 5 }} />
                          <Line type="monotone" dataKey="Sono" stroke="#6366f1" strokeWidth={3} dot={{ fill: '#6366f1', r: 5 }} />
                          <Line type="monotone" dataKey="Tempo Ecrã" stroke="#14b8a6" strokeWidth={3} dot={{ fill: '#14b8a6', r: 5 }} />
                          <Line type="monotone" dataKey="Exercício" stroke="#10b981" strokeWidth={3} dot={{ fill: '#10b981', r: 5 }} />
                        </LineChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>
                </motion.div>
              )}

              {/* Lista de Registos com Opção de Eliminar */}
              {userData.entries.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.6 }}
                >
                  <Card className="mt-6 bg-white/70 backdrop-blur-xl border-purple-100 shadow-lg">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2 text-2xl bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                        <Calendar className="w-6 h-6 text-purple-500" />
                        Histórico de Registos
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3 max-h-96 overflow-y-auto">
                        {userData.entries.map((entry, index) => (
                          <motion.div
                            key={entry.date}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: index * 0.05 }}
                            className="flex items-center justify-between p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg border border-purple-200 hover:shadow-md transition-shadow"
                          >
                            <div className="flex-1">
                              <p className="font-semibold text-purple-900 mb-2">{new Date(entry.date).toLocaleDateString('pt-PT', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
                              <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm">
                                <div className="flex items-center gap-1">
                                  <span className="text-xl">{moodEmojis[entry.mood - 1]}</span>
                                  <span className="text-gray-600">Humor: {entry.mood}/5</span>
                                </div>
                                <div className="flex items-center gap-1">
                                  <span className="text-xl">😴</span>
                                  <span className="text-gray-600">Sono: {entry.sleep}h</span>
                                </div>
                                <div className="flex items-center gap-1">
                                  <span className="text-xl">📱</span>
                                  <span className="text-gray-600">Ecrã: {entry.screenTime}h</span>
                                </div>
                                <div className="flex items-center gap-1">
                                  <span className="text-xl">🏃</span>
                                  <span className="text-gray-600">Exercício: {entry.exercise}min</span>
                                </div>
                              </div>
                            </div>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDeleteEntry(entry.date)}
                              className="ml-4 text-red-500 hover:text-red-700 hover:bg-red-50"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </motion.div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              )}
            </motion.div>
          </TabsContent>

          {/* Registo Diário - COM VALORES EM TEMPO REAL */}
          <TabsContent value="entry" className="mt-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <Card className="bg-white/70 backdrop-blur-xl border-purple-100 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-3xl bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent">
                    Como te sentes hoje?
                  </CardTitle>
                  <CardDescription className="text-lg">
                    Regista o teu dia e acompanha o teu bem-estar 💜
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-8">
                  {/* Humor */}
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <label className="text-lg font-semibold flex items-center gap-2">
                        <span className="text-2xl">😊</span> Humor
                      </label>
                      <div className="flex items-center gap-3">
                        <motion.span
                          className="text-4xl"
                          key={mood}
                          initial={{ scale: 0.5, rotate: -180 }}
                          animate={{ scale: 1, rotate: 0 }}
                          transition={{ type: "spring", stiffness: 200 }}
                        >
                          {moodEmojis[mood - 1]}
                        </motion.span>
                        <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white text-lg px-4 py-1">
                          {moodLabels[mood - 1]}
                        </Badge>
                      </div>
                    </div>
                    <Slider
                      value={[mood]}
                      onValueChange={(v) => setMood(v[0])}
                      min={1}
                      max={5}
                      step={1}
                      className="[&_[role=slider]]:bg-gradient-to-r [&_[role=slider]]:from-purple-500 [&_[role=slider]]:to-pink-500 [&_[role=slider]]:border-0 [&_[role=slider]]:shadow-lg"
                    />
                    <div className="flex justify-between text-sm text-gray-500">
                      <span>Muito Triste</span>
                      <span>Muito Feliz</span>
                    </div>
                  </div>

                  {/* Sono */}
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <label className="text-lg font-semibold flex items-center gap-2">
                        <span className="text-2xl">😴</span> Horas de Sono
                      </label>
                      <Badge className="bg-gradient-to-r from-indigo-500 to-blue-500 text-white text-lg px-4 py-1">
                        {sleep} horas
                      </Badge>
                    </div>
                    <Slider
                      value={[sleep]}
                      onValueChange={(v) => setSleep(v[0])}
                      min={0}
                      max={12}
                      step={0.5}
                      className="[&_[role=slider]]:bg-gradient-to-r [&_[role=slider]]:from-indigo-500 [&_[role=slider]]:to-blue-500 [&_[role=slider]]:border-0 [&_[role=slider]]:shadow-lg"
                    />
                    <div className="flex justify-between text-sm text-gray-500">
                      <span>0h</span>
                      <span>12h</span>
                    </div>
                  </div>

                  {/* Tempo de Ecrã */}
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <label className="text-lg font-semibold flex items-center gap-2">
                        <span className="text-2xl">📱</span> Tempo de Ecrã
                      </label>
                      <Badge className="bg-gradient-to-r from-cyan-500 to-teal-500 text-white text-lg px-4 py-1">
                        {screenTime} horas
                      </Badge>
                    </div>
                    <Slider
                      value={[screenTime]}
                      onValueChange={(v) => setScreenTime(v[0])}
                      min={0}
                      max={12}
                      step={0.5}
                      className="[&_[role=slider]]:bg-gradient-to-r [&_[role=slider]]:from-cyan-500 [&_[role=slider]]:to-teal-500 [&_[role=slider]]:border-0 [&_[role=slider]]:shadow-lg"
                    />
                    <div className="flex justify-between text-sm text-gray-500">
                      <span>0h</span>
                      <span>12h</span>
                    </div>
                  </div>

                  {/* Exercício */}
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <label className="text-lg font-semibold flex items-center gap-2">
                        <span className="text-2xl">🏃</span> Atividade Física
                      </label>
                      <Badge className="bg-gradient-to-r from-green-500 to-emerald-500 text-white text-lg px-4 py-1">
                        {exercise} minutos
                      </Badge>
                    </div>
                    <Slider
                      value={[exercise]}
                      onValueChange={(v) => setExercise(v[0])}
                      min={0}
                      max={120}
                      step={5}
                      className="[&_[role=slider]]:bg-gradient-to-r [&_[role=slider]]:from-green-500 [&_[role=slider]]:to-emerald-500 [&_[role=slider]]:border-0 [&_[role=slider]]:shadow-lg"
                    />
                    <div className="flex justify-between text-sm text-gray-500">
                      <span>0 min</span>
                      <span>120 min</span>
                    </div>
                  </div>

                  {/* Resumo em Tempo Real */}
                  <motion.div
                    className="p-6 bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl border-2 border-purple-200"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.3 }}
                  >
                    <h3 className="font-semibold text-lg mb-3 flex items-center gap-2">
                      <Sparkles className="w-5 h-5 text-purple-500" />
                      Resumo do Teu Dia
                    </h3>
                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div className="flex items-center gap-2">
                        <span className="text-2xl">{moodEmojis[mood - 1]}</span>
                        <span>Sentes-te <strong>{moodLabels[mood - 1]}</strong></span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-2xl">😴</span>
                        <span>Dormiste <strong>{sleep}h</strong></span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-2xl">📱</span>
                        <span><strong>{screenTime}h</strong> no ecrã</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-2xl">🏃</span>
                        <span><strong>{exercise}min</strong> de exercício</span>
                      </div>
                    </div>
                  </motion.div>

                  <Button
                    onClick={handleSubmitEntry}
                    className="w-full bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600 text-white text-lg py-6 shadow-lg"
                  >
                    <Star className="w-5 h-5 mr-2" />
                    Guardar Registo
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>

          {/* Análise */}
          <TabsContent value="analysis" className="space-y-6 mt-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h2 className="text-3xl font-bold bg-gradient-to-r from-indigo-600 to-cyan-600 bg-clip-text text-transparent mb-6">
                Análise Detalhada
              </h2>

              {userData.entries.length === 0 ? (
                <Card className="bg-white/70 backdrop-blur-xl border-purple-100">
                  <CardContent className="py-12 text-center">
                    <p className="text-gray-500 text-lg">Ainda não tens registos. Começa a registar o teu dia! 📝</p>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-6">
                  {/* Estatísticas em Cards */}
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
                      <Card className="bg-gradient-to-br from-purple-100 to-pink-100 border-purple-200">
                        <CardHeader>
                          <div className="flex items-center gap-3">
                            <div className="bg-gradient-to-br from-purple-500 to-pink-500 p-3 rounded-full">
                              <Heart className="w-6 h-6 text-white" />
                            </div>
                            <div>
                              <p className="text-sm text-gray-600">Humor Médio</p>
                              <p className="text-2xl font-bold text-purple-700">{stats.avgMood}/5</p>
                            </div>
                          </div>
                        </CardHeader>
                      </Card>
                    </motion.div>

                    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
                      <Card className="bg-gradient-to-br from-indigo-100 to-blue-100 border-indigo-200">
                        <CardHeader>
                          <div className="flex items-center gap-3">
                            <div className="bg-gradient-to-br from-indigo-500 to-blue-500 p-3 rounded-full">
                              <Moon className="w-6 h-6 text-white" />
                            </div>
                            <div>
                              <p className="text-sm text-gray-600">Sono Médio</p>
                              <p className="text-2xl font-bold text-indigo-700">{stats.avgSleep}h</p>
                            </div>
                          </div>
                        </CardHeader>
                      </Card>
                    </motion.div>

                    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
                      <Card className="bg-gradient-to-br from-cyan-100 to-teal-100 border-cyan-200">
                        <CardHeader>
                          <div className="flex items-center gap-3">
                            <div className="bg-gradient-to-br from-cyan-500 to-teal-500 p-3 rounded-full">
                              <Smartphone className="w-6 h-6 text-white" />
                            </div>
                            <div>
                              <p className="text-sm text-gray-600">Ecrã Médio</p>
                              <p className="text-2xl font-bold text-cyan-700">{stats.avgScreen}h</p>
                            </div>
                          </div>
                        </CardHeader>
                      </Card>
                    </motion.div>

                    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
                      <Card className="bg-gradient-to-br from-green-100 to-emerald-100 border-green-200">
                        <CardHeader>
                          <div className="flex items-center gap-3">
                            <div className="bg-gradient-to-br from-green-500 to-emerald-500 p-3 rounded-full">
                              <Activity className="w-6 h-6 text-white" />
                            </div>
                            <div>
                              <p className="text-sm text-gray-600">Exercício</p>
                              <p className="text-2xl font-bold text-green-700">{stats.avgExercise}min</p>
                            </div>
                          </div>
                        </CardHeader>
                      </Card>
                    </motion.div>
                  </div>

                  {/* Gráficos */}
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <Card className="bg-white/70 backdrop-blur-xl border-purple-100 shadow-lg">
                      <CardHeader>
                        <CardTitle className="text-xl">Comparação de Métricas</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ResponsiveContainer width="100%" height={300}>
                          <BarChart data={chartData}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#e9d5ff" />
                            <XAxis dataKey="data" stroke="#9333ea" />
                            <YAxis stroke="#9333ea" />
                            <Tooltip contentStyle={{ backgroundColor: 'rgba(255, 255, 255, 0.95)', borderRadius: '12px', border: '1px solid #e9d5ff' }} />
                            <Legend />
                            <Bar dataKey="Humor" fill="#ec4899" radius={[8, 8, 0, 0]} />
                            <Bar dataKey="Sono" fill="#6366f1" radius={[8, 8, 0, 0]} />
                          </BarChart>
                        </ResponsiveContainer>
                      </CardContent>
                    </Card>

                    <Card className="bg-white/70 backdrop-blur-xl border-purple-100 shadow-lg">
                      <CardHeader>
                        <CardTitle className="text-xl">Perfil de Bem-Estar</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ResponsiveContainer width="100%" height={300}>
                          <RadarChart data={radarData}>
                            <PolarGrid stroke="#e9d5ff" />
                            <PolarAngleAxis dataKey="category" stroke="#9333ea" />
                            <PolarRadiusAxis stroke="#9333ea" />
                            <Radar name="Bem-Estar" dataKey="value" stroke="#ec4899" fill="#ec4899" fillOpacity={0.6} />
                          </RadarChart>
                        </ResponsiveContainer>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Insights */}
                  <Card className="bg-gradient-to-br from-purple-50 to-pink-50 border-purple-200">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Sparkles className="w-6 h-6 text-purple-500" />
                        Insights Personalizados
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex items-start gap-3 p-3 bg-white/70 rounded-lg">
                        <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white">💜</Badge>
                        <p className="text-sm">
                          {parseFloat(stats.avgMood) >= 4
                            ? 'Ótimo! O teu humor tem estado positivo. Continua assim!'
                            : parseFloat(stats.avgMood) >= 3
                            ? 'O teu humor está equilibrado. Tenta incorporar atividades que gostas no teu dia.'
                            : 'Nota-se que tens estado mais em baixo. Considera falar com alguém de confiança.'}
                        </p>
                      </div>
                      <div className="flex items-start gap-3 p-3 bg-white/70 rounded-lg">
                        <Badge className="bg-gradient-to-r from-indigo-500 to-blue-500 text-white">😴</Badge>
                        <p className="text-sm">
                          {parseFloat(stats.avgSleep) >= 7
                            ? 'Excelente! Estás a dormir o suficiente para recuperar.'
                            : parseFloat(stats.avgSleep) >= 6
                            ? 'Tenta dormir mais uma hora para melhorar o teu bem-estar.'
                            : 'O sono é essencial! Tenta criar uma rotina noturna relaxante.'}
                        </p>
                      </div>
                      <div className="flex items-start gap-3 p-3 bg-white/70 rounded-lg">
                        <Badge className="bg-gradient-to-r from-green-500 to-emerald-500 text-white">🏃</Badge>
                        <p className="text-sm">
                          {parseFloat(stats.avgExercise) >= 30
                            ? 'Parabéns! Estás a cumprir a recomendação de atividade física.'
                            : parseFloat(stats.avgExercise) >= 15
                            ? 'Bom progresso! Tenta aumentar gradualmente a tua atividade.'
                            : 'Pequenas caminhadas podem fazer grande diferença no teu humor!'}
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}
            </motion.div>
          </TabsContent>

          {/* Recursos */}
          <TabsContent value="resources" className="mt-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="space-y-6"
            >
              <h2 className="text-3xl font-bold bg-gradient-to-r from-cyan-600 to-indigo-600 bg-clip-text text-transparent">
                Recursos de Apoio
              </h2>

              <Card className="bg-gradient-to-br from-red-50 to-orange-50 border-red-200 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-2xl text-red-700 flex items-center gap-2">
                    <AlertTriangle className="w-6 h-6" />
                    Emergência
                  </CardTitle>
                  <CardDescription className="text-base">Se estás em crise, não hesites em contactar:</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-white/70 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="bg-gradient-to-br from-red-500 to-orange-500 p-3 rounded-full">
                        <Phone className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <p className="font-semibold text-lg">Linha Saúde 24</p>
                        <p className="text-sm text-gray-600">Apoio médico e psicológico 24/7</p>
                      </div>
                    </div>
                    <a href="tel:808242424">
                      <Button className="bg-gradient-to-r from-red-500 to-orange-500 hover:from-red-600 hover:to-orange-600 text-white">
                        <Phone className="w-4 h-4 mr-2" />
                        808 24 24 24
                      </Button>
                    </a>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-white/70 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="bg-gradient-to-br from-purple-500 to-pink-500 p-3 rounded-full">
                        <MessageCircle className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <p className="font-semibold text-lg">SOS Voz Amiga</p>
                        <p className="text-sm text-gray-600">Apoio emocional e prevenção do suicídio</p>
                      </div>
                    </div>
                    <a href="tel:213544545">
                      <Button className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white">
                        <Phone className="w-4 h-4 mr-2" />
                        213 544 545
                      </Button>
                    </a>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-white/70 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="bg-gradient-to-br from-indigo-500 to-blue-500 p-3 rounded-full">
                        <Users className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <p className="font-semibold text-lg">Telefone da Amizade</p>
                        <p className="text-sm text-gray-600">Conversa anónima e confidencial</p>
                      </div>
                    </div>
                    <a href="tel:228323535">
                      <Button className="bg-gradient-to-r from-indigo-500 to-blue-500 hover:from-indigo-600 hover:to-blue-600 text-white">
                        <Phone className="w-4 h-4 mr-2" />
                        228 323 535
                      </Button>
                    </a>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white/70 backdrop-blur-xl border-purple-100 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-2xl bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                    Recursos Online
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <a
                    href="https://www.sns24.gov.pt/tema/saude-mental/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block"
                  >
                    <div className="p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg hover:shadow-md transition-all cursor-pointer border-2 border-transparent hover:border-purple-300">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-semibold mb-2 flex items-center gap-2">
                            🧠 SNS 24 - Saúde Mental
                            <ExternalLink className="w-4 h-4 text-purple-500" />
                          </h3>
                          <p className="text-sm text-gray-600">Informação sobre saúde mental e como pedir ajuda</p>
                        </div>
                      </div>
                    </div>
                  </a>
                  <a
                    href="https://apav.pt/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block"
                  >
                    <div className="p-4 bg-gradient-to-r from-indigo-50 to-blue-50 rounded-lg hover:shadow-md transition-all cursor-pointer border-2 border-transparent hover:border-indigo-300">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-semibold mb-2 flex items-center gap-2">
                            💙 Associação Portuguesa de Apoio à Vítima (APAV)
                            <ExternalLink className="w-4 h-4 text-indigo-500" />
                          </h3>
                          <p className="text-sm text-gray-600">Apoio a vítimas de violência e trauma</p>
                        </div>
                      </div>
                    </div>
                  </a>
                  <a
                    href="https://ilga-portugal.pt/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block"
                  >
                    <div className="p-4 bg-gradient-to-r from-cyan-50 to-teal-50 rounded-lg hover:shadow-md transition-all cursor-pointer border-2 border-transparent hover:border-cyan-300">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-semibold mb-2 flex items-center gap-2">
                            🌈 ILGA Portugal
                            <ExternalLink className="w-4 h-4 text-cyan-500" />
                          </h3>
                          <p className="text-sm text-gray-600">Apoio à comunidade LGBTQIA+</p>
                        </div>
                      </div>
                    </div>
                  </a>
                  <a
                    href="https://www.sosvozamiga.org/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block"
                  >
                    <div className="p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg hover:shadow-md transition-all cursor-pointer border-2 border-transparent hover:border-green-300">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-semibold mb-2 flex items-center gap-2">
                            💚 SOS Voz Amiga - Website
                            <ExternalLink className="w-4 h-4 text-green-500" />
                          </h3>
                          <p className="text-sm text-gray-600">Mais informações sobre apoio emocional</p>
                        </div>
                      </div>
                    </div>
                  </a>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-200">
                <CardHeader>
                  <CardTitle className="text-xl text-green-700">💚 Dicas de Bem-Estar</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 text-sm">
                  <p>✨ Pratica mindfulness 5 minutos por dia</p>
                  <p>🚶 Faz caminhadas ao ar livre</p>
                  <p>💬 Conversa com amigos e família</p>
                  <p>📝 Escreve num diário</p>
                  <p>🎨 Explora atividades criativas</p>
                  <p>😴 Mantém uma rotina de sono regular</p>
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
